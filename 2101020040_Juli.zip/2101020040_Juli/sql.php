<?php

	$server		= "localhost"; 
	$user		= "root";
	$password   	= ""; 
	$database	     = "2101020040_juli"; 

	$con = mysqli_connect($server,$user,$password,$database);

?>